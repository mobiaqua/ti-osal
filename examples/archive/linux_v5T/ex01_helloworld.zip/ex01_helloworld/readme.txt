Hello World Example

Program Logic:
This example shows how to build a simple app that uses
the XDC Runtime's System_printf() service to print "Hello World".

See http://rtsc.eclipse.org/docs-tip/RTSC_Module_Primer/Lesson_1